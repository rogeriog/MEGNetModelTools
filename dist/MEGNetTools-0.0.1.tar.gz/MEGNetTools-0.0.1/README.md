# MEGNet Tools
This package makes it easy to manipulate and generate custom MEGNet models. 
